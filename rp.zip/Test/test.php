<?php

$n = $_POST['name'];
$f = $_POST['fav_color'];

echo "Your name is " .$n ."<br> And your favorite color is ".$f;

?>