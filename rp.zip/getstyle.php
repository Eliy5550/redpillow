<?php

echo "<link rel='stylesheet' href='style.css'>";

?>